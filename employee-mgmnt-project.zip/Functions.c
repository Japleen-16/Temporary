#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>
#include "Employee.h"
void InputDetails(struct Employee emps[],int n)
{
    int len=n;
    printf("Enter the details of the employees\n");
    for(int i=0; i<len;i++)
    {
        //float bs;
        printf("Enter the employee number\n");
        scanf("%s",emps[i].EmpNo);
       // getchar();
        if (!isValidEmpNo(emps[i].EmpNo)) {
         printf("Invalid Employee Number. Please enter a valid number:\n");
         scanf("%s", emps[i].EmpNo);
      //   getchar();
        }
        
        printf("Enter the employee name\n");
        scanf("%s",emps[i].EmpName);
        while (!isValidName(emps[i].EmpName)) {
         printf("Invalid name. Please enter a valid name: \n");
         scanf("%s", emps[i].EmpName);
        }
        
        printf("Enter the employee hire date in dd mm yy order (only in numbers)\n");
        scanf("%d %d %d",&emps[i].hiredate.dd,&emps[i].hiredate.mm, &emps[i].hiredate.yy );
        while(isValidDate(emps[i].hiredate.dd,emps[i].hiredate.mm,emps[i].hiredate.yy))
        {
           // printf("Enter the valid Hiredate\n");
            scanf("%d %d %d",&emps[i].hiredate.dd,&emps[i].hiredate.mm, &emps[i].hiredate.yy );
            getchar();
        }
        
        
        printf("Enter the employee basic salary\n");
        scanf("%f", &emps[i].bs);
    }
}
void Display(struct Employee emps[],int n)
{
    int len=n;
    float bs;
    for(int i=0; i<len; i++)
    {
        printf("Employee Id: %s \n", emps[i].EmpNo);
        
        printf("Employee Name: %s \n", emps[i].EmpName);
       
        printf("Employee Hiredate: %d %d %d \n", emps[i].hiredate.dd, emps[i].hiredate.mm, emps[i].hiredate.yy);
       
        printf("The Gross Salary: %f \n", Netpay(emps[i].bs));
        
    }
}
float Netpay(float bs)
{
    float da=0, ta=0, pf=0;
    da=0.4*bs;
    ta=0.1*bs; pf=0.05*bs;
    float gs=0;
    gs=bs+da+ta-pf;
    return gs;
}

bool isValidEmpNo(const char *EmpNo) { 
  for (int i = 0; EmpNo[i]; i++) {
    if (!isdigit(EmpNo[i])) {
      return false;
    }
  }
  return true;
}

bool isValidName(const char *name) 
{
  for (int i = 0; name[i]; i++) {
    if (!isalpha(name[i])) {
      return false;
    }
  }
  return true;
}

int isValidDate(int dd, int mm, int yy) 
{
    if (yy < 2015 || mm < 1 || mm > 12 || dd < 1 || dd > 31) {
        printf("Please enter a valid hire date\n");
    }

    if ((mm == 4 || mm == 6 || mm == 9 || mm == 11) && dd > 30) {
        printf("Please enter a valid hire date\n");
    } else if (mm == 2) {
        if ((yy % 4 == 0 && yy % 100 != 0) || (yy % 400 == 0)) {
            if (dd > 29) {
               printf("Please enter a valid hire date\n");
            }
        } 
        else if (dd > 28) 
        {
           printf("Please enter a valid hire date\n");
        }
    }

    //return true; 
}