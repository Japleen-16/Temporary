#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
struct Date
        {
            int dd,mm,yy;
        };
struct Employee
    {
        char EmpNo[10];
        char EmpName[26];
        
        struct Date hiredate;
        float bs;
        
    };
    float Netpay(float bs);
    void InputDetails(struct Employee emps[],int n);
    void Display(struct Employee emps[],int n);
    bool isValidEmpNo(const char *EmpNo);
    bool isValidName(const char *name) ;
    