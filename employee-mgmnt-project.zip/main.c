/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include "Employee.h"

int main()
{
    
    printf("*EMPLOYEE MANAGEMENT SYSTEM* \n");
    int n=0;
    printf("Please enter the number of employees for the system\n");
    scanf("%d",&n);
    struct Employee emps[n];
    InputDetails( emps,n);
    Display( emps,n);
    
    

    return 0;
}



